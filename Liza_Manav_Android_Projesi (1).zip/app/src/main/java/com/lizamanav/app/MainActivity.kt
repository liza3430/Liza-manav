package com.lizamanav.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

class DB(ctx: Context): SQLiteOpenHelper(ctx, "liza_manav.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT)")
        db.execSQL("CREATE TABLE entries(id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER,kind TEXT,amount REAL,note TEXT,date TEXT)")
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,buy REAL,sell REAL,stock REAL)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,total REAL,cost REAL,date TEXT,note TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCustomer(n:String,p:String) { writableDatabase.execSQL("INSERT INTO customers(name,phone) VALUES(?,?)", arrayOf(n,p)) }
    fun customers(): List<Array<String>> {
        val out= mutableListOf<Array<String>>(); val c=readableDatabase.rawQuery("SELECT id,name,phone FROM customers ORDER BY name",null)
        while(c.moveToNext()) out.add(arrayOf(c.getString(0),c.getString(1),c.getString(2))); c.close(); return out
    }
    fun addEntry(id:Int,kind:String,amount:Double,note:String) {
        writableDatabase.execSQL("INSERT INTO entries(customerId,kind,amount,note,date) VALUES(?,?,?,?,?)",
            arrayOf(id,kind,amount,note,now()))
    }
    fun balance(id:Int):Double {
        val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='BORÇ' THEN amount ELSE -amount END),0) FROM entries WHERE customerId=?", arrayOf(id.toString()))
        c.moveToFirst(); val v=c.getDouble(0); c.close(); return v
    }
    fun customerPhone(id:Int):String { val c=readableDatabase.rawQuery("SELECT phone FROM customers WHERE id=?",arrayOf(id.toString())); c.moveToFirst(); val v=c.getString(0) ?: ""; c.close(); return v }
    fun addProduct(n:String,b:Double,s:Double,st:Double) { writableDatabase.execSQL("INSERT INTO products(name,buy,sell,stock) VALUES(?,?,?,?)",arrayOf(n,b,s,st)) }
    fun products():List<Array<String>> { val a= mutableListOf<Array<String>>(); val c=readableDatabase.rawQuery("SELECT id,name,buy,sell,stock FROM products ORDER BY name",null); while(c.moveToNext()) a.add(arrayOf(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4))); c.close(); return a }
    fun addSale(total:Double,cost:Double,note:String) { writableDatabase.execSQL("INSERT INTO sales(total,cost,date,note) VALUES(?,?,?,?)",arrayOf(total,cost,now(),note)) }
    fun totals():Pair<Double,Double> { val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(total-cost),0) FROM sales WHERE date LIKE ?",arrayOf(today()+"%")); c.moveToFirst(); val p=Pair(c.getDouble(0),c.getDouble(1)); c.close(); return p }
    fun debtTotal():Double { val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN kind='BORÇ' THEN amount ELSE -amount END),0) FROM entries",null); c.moveToFirst(); val x=c.getDouble(0); c.close(); return x }
    companion object { fun now()=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale("tr","TR")).format(Date()); fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()) }
}

class MainActivity: Activity() {
    private lateinit var db:DB; private lateinit var root:LinearLayout
    private val green=Color.rgb(20,83,45)
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); db=DB(this); showHome() }
    private fun setup(title:String) {
        root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(18,18,18,18); root.setBackgroundColor(Color.rgb(247,249,246))
        val head=TextView(this); head.text="🍎  LİZA MANAV\n$title"; head.textSize=22f; head.setTextColor(Color.WHITE); head.setPadding(18,18,18,18); head.setBackgroundColor(green); root.addView(head)
        val scroll=ScrollView(this); val body=LinearLayout(this); body.orientation=LinearLayout.VERTICAL; body.setPadding(0,12,0,20); scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.orientation=LinearLayout.HORIZONTAL
        listOf("Ana Sayfa","Satış","Müşteriler","Ürünler","Rapor").forEach { label -> val b=Button(this); b.text=label; b.textSize=10f; b.setOnClickListener { when(label){"Ana Sayfa"->showHome();"Satış"->showSales();"Müşteriler"->showCustomers();"Ürünler"->showProducts();else->showReport()} }; nav.addView(b,LinearLayout.LayoutParams(0,-2,1f)) }
        root.addView(nav); setContentView(root); body.tag="body"
    }
    private fun body():LinearLayout = (root.getChildAt(1) as ScrollView).getChildAt(0) as LinearLayout
    private fun text(t:String,size:Float=16f) { val v=TextView(this); v.text=t; v.textSize=size; v.setTextColor(Color.DKGRAY); v.setPadding(8,12,8,12); body().addView(v) }
    private fun field(hint:String):EditText { val e=EditText(this); e.hint=hint; e.textSize=16f; body().addView(e); return e }
    private fun btn(t:String, action:()->Unit) { val b=Button(this); b.text=t; b.setOnClickListener{action()}; body().addView(b) }
    private fun money(x:Double)="%,.2f TL".format(Locale("tr","TR"),x)
    private fun showHome() { setup("İşletme Özeti"); val p=db.totals()
        text("Bugünkü ciro: ${money(p.first)}",22f); text("Bugünkü tahmini brüt kâr: ${money(p.second)}",18f); text("Toplam açık veresiye: ${money(db.debtTotal())}",18f)
        text("Hızlı işlemler",18f); btn("Yeni satış"){showSales()}; btn("Müşteri / veresiye ekle"){showCustomers()}; btn("Ürün ekle"){showProducts()}; btn("Raporları gör"){showReport()}
        text("Bilgi: Kayıtlar bu telefonda yerel olarak saklanır. Telefon değişiminden önce yedek alın.")
    }
    private fun showSales() { setup("Satış Kaydı")
        val total=field("Satış tutarı (TL)"); val cost=field("Ürünlerin alış maliyeti (TL)"); val note=field("Açıklama (isteğe bağlı)")
        btn("Satışı Kaydet") { val t=total.text.toString().replace(",",".").toDoubleOrNull(); val c=cost.text.toString().replace(",",".").toDoubleOrNull()
            if(t==null || c==null || t<0 || c<0) toast("Geçerli tutar girin") else { db.addSale(t,c,note.text.toString()); toast("Satış kaydedildi"); showHome() } }
        text("Kâr, satış tutarı eksi alış maliyeti olarak hesaplanır.")
    }
    private fun showCustomers() { setup("Müşteriler ve Veresiye")
        val n=field("Müşteri adı"); val p=field("Telefon (WhatsApp için)")
        btn("Müşteri ekle"){ if(n.text.isBlank()) toast("Müşteri adı gerekli") else { db.addCustomer(n.text.toString(),p.text.toString()); showCustomers() } }
        text("Müşteri listesi",18f)
        db.customers().forEach { a -> val id=a[0].toInt(); val bal=db.balance(id)
            text("${a[1]}  •  ${money(bal)} borç")
            btn("Borç / tahsilat işlemi: ${a[1]}"){entryDialog(id,a[1])}
            btn("WhatsApp borç mesajı gönder"){whatsapp(a[1],a[2],bal)}
        }
    }
    private fun entryDialog(id:Int,name:String) {
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; val amount=EditText(this); amount.hint="Tutar (TL)"; amount.inputType=8194
        val note=EditText(this); note.hint="Açıklama"; box.addView(amount); box.addView(note)
        val kinds=arrayOf("BORÇ","TAHSİLAT"); var kind="BORÇ"
        AlertDialog.Builder(this).setTitle(name).setView(box).setSingleChoiceItems(kinds,0){_,which->kind=kinds[which]}
            .setPositiveButton("Kaydet"){_,_-> val v=amount.text.toString().replace(",",".").toDoubleOrNull(); if(v!=null && v>0){db.addEntry(id,kind,v,note.text.toString());showCustomers()} else toast("Tutarı kontrol edin")}
            .setNegativeButton("İptal",null).show()
    }
    private fun whatsapp(name:String,phone:String,balance:Double) {
        if(phone.isBlank()){toast("Önce müşterinin telefon numarasını kaydedin");return}
        val digits=phone.filter{it.isDigit()}.let{if(it.startsWith("0")) "90"+it.drop(1) else if(it.startsWith("90")) it else "90$it"}
        val msg="Merhaba $name, LİZA MANAV hesabınızdaki güncel veresiye bakiyeniz ${money(balance)}. Bilginize."
        try { val i=Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://wa.me/$digits?text="+java.net.URLEncoder.encode(msg,"UTF-8"))); startActivity(i) } catch(e:Exception){toast("WhatsApp açılamadı")}
    }
    private fun showProducts() { setup("Ürünler ve Fiyatlar")
        val n=field("Ürün adı"); val b=field("Alış fiyatı (TL)"); val s=field("Satış fiyatı (TL)"); val st=field("Stok miktarı")
        btn("Ürün ekle"){ val bv=b.text.toString().replace(",",".").toDoubleOrNull(); val sv=s.text.toString().replace(",",".").toDoubleOrNull(); val q=st.text.toString().replace(",",".").toDoubleOrNull()
            if(n.text.isBlank()||bv==null||sv==null||q==null) toast("Tüm alanları doğru doldurun") else {db.addProduct(n.text.toString(),bv,sv,q);showProducts()} }
        db.products().forEach{ text("${it[1]}  | Alış ${money(it[2].toDouble())} | Satış ${money(it[3].toDouble())} | Stok ${it[4]}") }
    }
    private fun showReport() { setup("Raporlar")
        val p=db.totals(); text("Bugünkü ciro: ${money(p.first)}",21f); text("Bugünkü brüt kâr: ${money(p.second)}",19f); text("Toplam veresiye bakiyesi: ${money(db.debtTotal())}",19f)
        text("Satış kayıtları yalnızca satış ekranında girilen toplam ve maliyet üzerinden raporlanır.")
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}
