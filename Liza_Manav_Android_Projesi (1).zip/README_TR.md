# LİZA MANAV – Android uygulama projesi

## İçerik
- Günlük satış ve brüt kâr kaydı
- Ürün alış/satış fiyatı ve stok kaydı
- Müşteri listesi, borç ve tahsilat hareketleri
- WhatsApp üzerinden hazır borç bildirimi (gönder tuşuna WhatsApp içinde siz basarsınız)
- Günlük özet ve toplam veresiye

## APK oluşturma (bilgisayarda Android Studio gerekir)
1. Android Studio'yu kurun.
2. Bu ZIP dosyasını açın ve `LizaManavAndroid` klasörünü Android Studio ile açın.
3. Gradle eşitlemesinin bitmesini bekleyin.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK, `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.
6. APK'yı Android telefonunuza aktarın ve kurun. Telefon kurulum sırasında bu kaynağa izin isteyebilir.

## Önemli yedekleme notu
Bu ilk sürüm kayıtları telefondaki SQLite veritabanında tutar. Firebase bulut yedekleme henüz etkin değildir; bunun için size ait Firebase projesi, `google-services.json` ve güvenli erişim kuralları gerekir. Bu dosyalar olmadan buluta yedekleme çalışıyor denemez. İlk kurulumdan önce gerçek müşteri verisi girmeden test edin.

## Sürüm sınırları
Bu başlangıç sürümünde satışlar tutar/maliyet olarak kaydedilir; ürün stoğu satışla otomatik düşmez. Vergi/POS/e-fatura entegrasyonu içermez.
